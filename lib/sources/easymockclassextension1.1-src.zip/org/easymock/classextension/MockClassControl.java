/*
 * Copyright (c) 2003-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */

package org.easymock.classextension;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.easymock.MockControl;
import org.easymock.internal.IBehaviorFactory;
import org.easymock.internal.IProxyFactory;
import org.easymock.internal.RecordState;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

/**
 * Instances of <code>MockControl</code> control the behavior of their
 * associated mock objects. For more information, see the EasyMock
 * documentation.
 */
public class MockClassControl extends MockControl {

   private static InvocationHandler donothing = new InvocationHandler() {
      public Object invoke(Object proxy, Method method, Object[] args) throws
         Throwable {
         return null;
      }
   };

   static class ClassProxyFactory implements IProxyFactory {

      private Object[] constructorArgs;
      private Class[] constructorTypes;
      private Set mockedMethods;

      public ClassProxyFactory(
         Class[] constructorTypes,
         Object[] constructorArgs,
         Method[] mockedMethods) {
         this.constructorTypes = constructorTypes;
         this.constructorArgs = constructorArgs;
         this.mockedMethods = mockedMethods == null ? null : new HashSet(Arrays.asList(mockedMethods));
      }

      public Object createProxy(
         Class toMock,
         final InvocationHandler handler) {
         MethodInterceptor interceptor = new MethodInterceptor() {
            public Object intercept(
               Object obj,
               Method method,
               Object[] args,
               MethodProxy proxy) throws Throwable {
               if(mockedMethods != null && !mockedMethods.contains(method)) {
                 return proxy.invokeSuper(obj, args);
               }
               return handler.invoke(proxy, method, args);
            }
         };
         try {
            // If no constructorTypes specified, try to use first constructor found.
            if (constructorTypes == null) {
               Constructor constructor = getConstructorToUse(toMock);
               constructorTypes = constructor.getParameterTypes();
               constructorArgs = getArgsForTypes(constructorTypes);
            }
            // Create the mock
            Enhancer enhancer = new Enhancer();
            enhancer.setSuperclass(toMock);
            enhancer.setCallback(interceptor);
            return enhancer.create(constructorTypes, constructorArgs);

         } catch(RuntimeException e) {
            throw e;
         } catch(Exception e) {
            throw new Error(e);
         }
      }
   }

   /**
    * Return the wrapping type for each primitive type
    * @param type A primitive type
    * @return Object A wrapper with a default value
    */
   private static Object handlePrimitiveType(Class type) {
      return RecordState.emptyReturnValueFor(type);
   }

   /**
    * Return the constructor considered the best to use with this class.
    * Algorithm is: No args constructor and then first constructor defined in the class
    * @param clazz Class searched
    * @return Constructor to use
    */
   private static Constructor getConstructorToUse(Class clazz) {
      // First try to use the default constructor
      try {
         return clazz.getConstructor(new Class[0]);
      }
      catch (NoSuchMethodException e) {
         // If it fails just use the first one
         if(clazz.getConstructors().length == 0) {
            throw new IllegalArgumentException("No visible constructors in class " + clazz.getName());
         }
         return clazz.getConstructors()[0];
      }
   }

   /**
    * Get some default args to will fit the provided method types
    * @param methodTypes Class[]
    * @return Objects fitting the methodTypes in order
    */
   private static Object[] getArgsForTypes(Class[] methodTypes) {
      Object[] methodArgs = new Object[methodTypes.length];

      for(int i = 0; i < methodTypes.length; i++) {
         if(methodTypes[i].isInterface()) {
            // Just return a dynamic proxy
            methodArgs[i] = Proxy.newProxyInstance(methodTypes[i].getClassLoader(), new Class[] {methodTypes[i]}, donothing);
         }
         else if(methodTypes[i].isPrimitive()) {
            // Return a nice wrapped primitive type
            methodArgs[i] = handlePrimitiveType(methodTypes[i]);
         }
         else if(Modifier.isFinal(methodTypes[i].getModifiers())) {
            // Instantiate the class using the best constructor we can find (because it's not possible to mock a final class)
            Constructor argConstructor = getConstructorToUse(methodTypes[i]);
            try {
               methodArgs[i] = argConstructor.newInstance(getArgsForTypes(argConstructor.getParameterTypes()));
            }
            catch (Exception ex) {
               throw new Error(ex);
            }
         }
         else {
            // Just create a mock for the class...
            MockControl ctrl = MockClassControl.createControl(methodTypes[i]);
            methodArgs[i] = ctrl.getMock();
         }
      }
      return methodArgs;
   }

   /**
    * Creates a mock control object for the specified class and construct an
    * instance using the constructor that matches <code>constructorTypes</code>
    * with parameters <code>constructorArgs</code>.
    *
    * The {@link MockControl} and its
    * associated mock object
    * will not check the order of expected method calls.
    * An unexpected method call on the mock object will
    * lead to an <code>AssertionFailedError</code>.
    *
    * @param classToMock the class to mock.
    * @param constructorTypes Class types of arguments in constructor to use
    * to instantiate object
    * @param constructorArgs objects to pass to constructor.
    * @return the mock control.
    */
   public static MockClassControl createControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         UNORDERED_BEHAVIOR_FACTORY);
   }

   /**
    * Do the same as above but allows to pass a list of methods to mock. All the others won't be. If you pass null, no
    * methods will be mocked.
    */
   public static MockClassControl createControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs,
      Method[] mockedMethods) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         mockedMethods,
         UNORDERED_BEHAVIOR_FACTORY);
   }

   /**
    * Does the same thing as above, but tries to use the best constructor. The algorithm is pretty basic. It first search
    * for an empty constructor. If none exists, it will just use the first constructor it finds. The constructor params
    * will be mocked (in case of interfaces and not final classes) or filled with default values (for final classes or
    * primitive types). If the picked constructor is using it's parameters to do some business treatment, it is highly
    * possible that the generated params won't be enough and it will crash. In this case you should use
    * <code>createControl(Class, Class[], Object[])</code> to be able to use your own params and constructor.
    *
    * @see org.easymock.MockClassControl#createControl(java.lang.Class, java.lang.Class[], java.lang.Object[])
    */
   public static MockControl createControl(Class classToMock) {
      if (classToMock.isInterface()) {
         return MockControl.createControl(classToMock);
      }
      else {
         return new MockClassControl(
            classToMock,
            null,
            null,
            UNORDERED_BEHAVIOR_FACTORY);
      }
   }

   /**
    * Creates a mock control object for the specified class and construct an
    * instance using the constructor that matches <code>constructorTypes<code>
    * with parameters <code>constructorArgs</code>.
    *
    * The {@link MockControl} and its
    * associated mock object
    * will check the order of expected method calls.
    * An unexpected method call on the mock object will
    * lead to an <code>AssertionFailedError</code>.
    *
    * @param classToMock the class to mock.
    * @param constructorTypes Class types of arguments in constructor to use
    * to instantiate object
    * @param constructorArgs objects to pass to constructor.
    * @return the mock control.
    */
   public static MockClassControl createStrictControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         ORDERED_BEHAVIOR_FACTORY);
   }

   /**
    * Do the same as above but allows to pass a list of methods to mock. All the others won't be. If you pass null, no
    * methods will be mocked.
    */
   public static MockClassControl createStrictControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs,
      Method[] mockedMethods) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         mockedMethods,
         ORDERED_BEHAVIOR_FACTORY);
   }

   /**
    * Does the same thing as above, but tries to use the first constructor found.
    *
    * @see org.easymock.MockClassControl#createStrictControl(java.lang.Class, java.lang.Class[], java.lang.Object[])
    */
   public static MockControl createStrictControl(Class classToMock) {
      if (classToMock.isInterface()) {
         return MockControl.createStrictControl(classToMock);
      }
      else {
         return new MockClassControl(
            classToMock,
            null,
            null,
            ORDERED_BEHAVIOR_FACTORY);
      }
   }

   /**
    * Creates a mock control object for the specified class and construct an
    * instance using the constructor that matches <code>constructorTypes<code>
    * with parameters <code>constructorArgs</code>.
    *
    * The {@link MockControl} and its
    * associated mock object
    * will not the order of expected method calls.
    * An unexpected method call on the mock object will
    * return an empty value (0, null, false).
    *
    * @param classToMock the class to mock.
    * @param constructorTypes Class types of arguments in constructor to use
    * to instantiate object
    * @param constructorArgs objects to pass to constructor.
    * @return the mock control.
    */
   public static MockClassControl createNiceControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         NICE_BEHAVIOR_FACTORY);
   }

   /**
    * Do the same as above but allows to pass a list of methods to mock. All the others won't be. If you pass null, no
    * methods will be mocked.
    */
   public static MockClassControl createNiceControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs,
      Method[] mockedMethods) {
      return new MockClassControl(
         classToMock,
         constructorTypes,
         constructorArgs,
         mockedMethods,
         NICE_BEHAVIOR_FACTORY);
   }

   /**
    * Does the same thing as above, but tries to use the first constructor found.
    *
    * @see org.easymock.MockClassControl#createNiceControl(java.lang.Class, java.lang.Class[], java.lang.Object[])
    */
   public static MockControl createNiceControl(Class classToMock) {
      if (classToMock.isInterface()) {
         return MockControl.createNiceControl(classToMock);
      }
      else {
         return new MockClassControl(
            classToMock,
            null,
            null,
            NICE_BEHAVIOR_FACTORY);
      }
   }

   private MockClassControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs,
      Method[] mockedMethods,
      IBehaviorFactory behaviorFactory) {
      super(
         classToMock,
         new ClassProxyFactory(constructorTypes, constructorArgs, mockedMethods),
         behaviorFactory);
   }

   private MockClassControl(
      Class classToMock,
      Class[] constructorTypes,
      Object[] constructorArgs,
      IBehaviorFactory behaviorFactory) {
      this(classToMock, constructorTypes, constructorArgs, null, behaviorFactory);
   }

}
